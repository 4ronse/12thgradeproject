C# version
